# متابعتي — جامع بالبيد القرآني · V5

نظام SaaS عربي RTL لإدارة حلقات القرآن الكريم، الطلاب، الحضور، التقييمات، الأهداف، الإعلانات، التقارير وبوابة ولي الأمر.

## التقنية

- **Backend:** FastAPI + SQLAlchemy
- **Database:** SQLite للتطوير / PostgreSQL للإنتاج
- **Auth:** JWT + أدوار وصلاحيات
- **Frontend:** HTML + CSS + Vanilla JavaScript RTL
- **Migrations:** Alembic
- **Deployment:** Docker + Docker Compose
- **CI:** GitHub Actions + Pytest

## أهم ما يميز V5

- مستودع GitHub منظم وجاهز للـPull Requests.
- الأسرار خارج Git عبر `.env`.
- دعم PostgreSQL الحقيقي للإنتاج.
- ترحيلات قاعدة البيانات بدل الاعتماد على `create_all`.
- API والواجهة يعملان من نفس الدومين.
- `/docs` و`/redoc` لتوثيق الـAPI.
- Health Check في `/api/health`.
- اختبارات Smoke آلية.
- Docker Compose مع PostgreSQL وHealth Check.
- GitHub Actions لفحص المشروع تلقائيًا.
- قوالب Issues وملفات SECURITY وCONTRIBUTING.
- حماية أساسية عبر Security Headers وCORS قابل للضبط.

## التشغيل المحلي

### 1. البيئة

```bash
python -m venv .venv
# Windows
.venv\\Scripts\\activate
# macOS/Linux
source .venv/bin/activate
pip install -r backend/requirements.txt
```

### 2. الإعدادات

انسخ `.env.example` إلى `.env` وعدّل `SECRET_KEY`.

### 3. قاعدة البيانات

```bash
alembic upgrade head
python -m backend.seed
```

### 4. التشغيل

```bash
uvicorn backend.main:app --reload
```

افتح:

- الموقع: `http://127.0.0.1:8000`
- API Docs: `http://127.0.0.1:8000/docs`
- Health: `http://127.0.0.1:8000/api/health`

## الحسابات التجريبية

> هذه الحسابات للتطوير فقط ويجب تغييرها أو حذفها قبل الإنتاج.

- الإدارة: `admin` / `Admin@12345`
- المعلم: `teacher` / `Teacher@12345`
- ولي الأمر: `guardian` / `Guardian@12345`
- ولي أمر ثانٍ: `guardian2` / `Guardian@12345`

## التشغيل باستخدام Docker

1. أنشئ `.env` وضع `SECRET_KEY` قويًا و`POSTGRES_PASSWORD` قويًا.
2. شغّل:

```bash
docker compose up -d --build
```

ستعمل الخدمة على المنفذ `8000`، وسيتم تنفيذ `alembic upgrade head` تلقائيًا عند بدء الحاوية.

## النشر على GitHub

```bash
git init
git add .
git commit -m "feat: release V5 production foundation"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/balbeid-quran.git
git push -u origin main
```

لا ترفع `.env` أو قاعدة البيانات المحلية. GitHub Actions سيشغّل الفحص والاختبارات عند كل Push وPull Request إلى `main` أو `master`.

## متغيرات الإنتاج

| المتغير | المطلوب | الوصف |
|---|---|---|
| `APP_ENV` | نعم | `production` |
| `SECRET_KEY` | نعم | مفتاح JWT عشوائي قوي |
| `DATABASE_URL` | نعم | رابط PostgreSQL |
| `ACCESS_TOKEN_EXPIRE_HOURS` | اختياري | مدة الجلسة |
| `CORS_ORIGINS` | اختياري | الدومينات المسموح لها بالوصول |

## بنية المشروع

```text
.
├── backend/
│   ├── auth.py
│   ├── config.py
│   ├── database.py
│   ├── main.py
│   ├── models.py
│   └── seed.py
├── frontend/
│   ├── index.html
│   ├── app.js
│   └── style.css
├── alembic/
├── tests/
├── .github/
├── Dockerfile
├── docker-compose.yml
├── docker-entrypoint.sh
├── alembic.ini
├── .env.example
├── CONTRIBUTING.md
├── SECURITY.md
└── LICENSE
```

## قبل الإطلاق التجاري

- تغيير الحسابات التجريبية.
- استخدام HTTPS ودومين رسمي.
- تفعيل نسخ PostgreSQL الاحتياطية.
- وضع أسرار الإنتاج في GitHub Secrets أو مزود الاستضافة، وليس في المستودع.
- إضافة مزود بريد/SMS/WhatsApp رسمي عند الحاجة.
- إضافة مراقبة Logs وError Tracking.
- مراجعة سياسة الخصوصية وحفظ بيانات الطلاب وفق الأنظمة المحلية.
