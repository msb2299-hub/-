"""initial schema"""
from alembic import op
import sqlalchemy as sa
revision='0001_initial'
down_revision=None
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('users', sa.Column('id',sa.Integer(),primary_key=True), sa.Column('username',sa.String(80),nullable=False), sa.Column('password_hash',sa.String(255),nullable=False), sa.Column('role',sa.String(20),nullable=False), sa.Column('full_name',sa.String(120),nullable=False), sa.Column('phone',sa.String(30)), sa.Column('is_active',sa.Boolean(),nullable=False,server_default=sa.true()))
    op.create_index('ix_users_username','users',['username'],unique=True); op.create_index('ix_users_role','users',['role'])
    op.create_table('students', sa.Column('id',sa.Integer(),primary_key=True), sa.Column('full_name',sa.String(120),nullable=False), sa.Column('guardian_id',sa.Integer(),sa.ForeignKey('users.id')), sa.Column('teacher_id',sa.Integer(),sa.ForeignKey('users.id')), sa.Column('circle',sa.String(120)), sa.Column('current_surah',sa.String(120)), sa.Column('current_juz',sa.Integer()), sa.Column('progress',sa.Integer(),nullable=False,server_default='0'), sa.Column('memorized_pages',sa.Integer(),nullable=False,server_default='0'), sa.Column('starred',sa.Boolean(),nullable=False,server_default=sa.false()), sa.Column('notes',sa.Text()))
    op.create_index('ix_students_full_name','students',['full_name']); op.create_index('ix_students_circle','students',['circle'])
    op.create_table('attendance', sa.Column('id',sa.Integer(),primary_key=True), sa.Column('student_id',sa.Integer(),sa.ForeignKey('students.id'),nullable=False), sa.Column('date',sa.String(10),nullable=False), sa.Column('status',sa.String(20),nullable=False), sa.Column('note',sa.Text()), sa.UniqueConstraint('student_id','date',name='uq_student_date'))
    op.create_index('ix_attendance_date','attendance',['date'])
    op.create_table('evaluations', sa.Column('id',sa.Integer(),primary_key=True), sa.Column('student_id',sa.Integer(),sa.ForeignKey('students.id'),nullable=False), sa.Column('score',sa.Integer(),nullable=False), sa.Column('type',sa.String(80),nullable=False,server_default='تقييم'), sa.Column('notes',sa.Text()), sa.Column('date',sa.String(10),nullable=False)); op.create_index('ix_evaluations_date','evaluations',['date'])
    op.create_table('guardian_contacts', sa.Column('id',sa.Integer(),primary_key=True), sa.Column('student_id',sa.Integer(),sa.ForeignKey('students.id'),nullable=False,unique=True), sa.Column('name',sa.String(120),nullable=False), sa.Column('phone',sa.String(30),nullable=False))
    op.create_table('announcements', sa.Column('id',sa.Integer(),primary_key=True), sa.Column('title',sa.String(200),nullable=False), sa.Column('body',sa.Text(),nullable=False), sa.Column('created_at',sa.String(30),nullable=False), sa.Column('active',sa.Boolean(),nullable=False,server_default=sa.true()))
    op.create_table('committee_tasks', sa.Column('id',sa.Integer(),primary_key=True), sa.Column('text',sa.String(300),nullable=False), sa.Column('done',sa.Boolean(),nullable=False,server_default=sa.false()))
    op.create_table('committee_achievements', sa.Column('id',sa.Integer(),primary_key=True), sa.Column('text',sa.String(300),nullable=False))
    op.create_table('term_goals', sa.Column('id',sa.Integer(),primary_key=True), sa.Column('student_id',sa.Integer(),sa.ForeignKey('students.id'),nullable=False), sa.Column('term',sa.String(40),nullable=False), sa.Column('target',sa.String(200),nullable=False), sa.Column('percent',sa.Integer(),nullable=False,server_default='0'))

def downgrade():
    for t in ['term_goals','committee_achievements','committee_tasks','announcements','guardian_contacts','evaluations','attendance','students','users']:
        op.drop_table(t)
