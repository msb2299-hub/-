from datetime import datetime, timedelta, timezone
from jose import jwt
from passlib.context import CryptContext
from .config import settings

ALGORITHM = "HS256"
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str):
    return pwd_context.hash(password)

def verify_password(password: str, hashed: str):
    return pwd_context.verify(password, hashed)

def create_token(user):
    payload = {"sub": str(user.id), "role": user.role,
               "exp": datetime.now(timezone.utc) + timedelta(hours=settings.access_token_expire_hours)}
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)

def decode_token(token):
    return jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
