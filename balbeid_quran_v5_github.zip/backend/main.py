from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.security import OAuth2PasswordBearer
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from datetime import datetime
from .database import Base, engine, get_db
from .models import *
from .auth import *
from .config import settings

app = FastAPI(title=settings.app_name, version='5.0.0', docs_url='/docs', redoc_url='/redoc')
origins = settings.cors_list or ([] if settings.app_env == 'production' else ['*'])
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=bool(origins and origins != ['*']), allow_methods=['*'], allow_headers=['*'])

@app.middleware('http')
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    return response
oauth2_scheme = OAuth2PasswordBearer(tokenUrl='/api/auth/login')

class LoginIn(BaseModel): username:str; password:str; role:str
class StudentIn(BaseModel):
    full_name:str; guardian_id:int|None=None; teacher_id:int|None=None; circle:str|None=None; current_surah:str|None=None; current_juz:int|None=None
    progress:int=Field(0,ge=0,le=100); memorized_pages:int=Field(0,ge=0); starred:bool=False; notes:str|None=None
class AttendanceIn(BaseModel): student_id:int; date:str; status:str; note:str|None=None
class EvaluationIn(BaseModel): student_id:int; score:int=Field(...,ge=0,le=100); type:str='تقييم'; notes:str|None=None; date:str
class GuardianIn(BaseModel): name:str; phone:str
class AnnouncementIn(BaseModel): title:str; body:str
class GoalIn(BaseModel): student_id:int; term:str; target:str; percent:int=Field(0,ge=0,le=100)
class TextIn(BaseModel): text:str
class UserIn(BaseModel): username:str; password:str|None=None; full_name:str; role:str; phone:str|None=None; is_active:bool=True
class UserStatusIn(BaseModel): is_active:bool

ROLES={'admin','teacher','guardian'}
def get_user(token=Depends(oauth2_scheme), db:Session=Depends(get_db)):
    try: u=db.get(User,int(decode_token(token)['sub']))
    except Exception: raise HTTPException(401,'جلسة الدخول غير صالحة')
    if not u or not u.is_active: raise HTTPException(401,'الحساب غير صالح')
    return u

def role(*allowed):
    def dep(u=Depends(get_user)):
        if u.role not in allowed: raise HTTPException(403,'ليس لديك صلاحية لهذا الإجراء')
        return u
    return dep

def student_dict(s,db):
    g=db.query(GuardianContact).filter_by(student_id=s.id).first()
    teacher=db.get(User,s.teacher_id) if s.teacher_id else None
    return {'id':s.id,'full_name':s.full_name,'guardian_id':s.guardian_id,'teacher_id':s.teacher_id,'teacher_name':teacher.full_name if teacher else '',
            'circle':s.circle,'current_surah':s.current_surah,'current_juz':s.current_juz,'progress':s.progress,'memorized_pages':s.memorized_pages,'starred':s.starred,'notes':s.notes or '',
            'guardian_name':g.name if g else '', 'guardian_phone':g.phone if g else ''}

def allowed_student(s,u): return u.role=='admin' or (u.role=='teacher' and s.teacher_id==u.id)

def profile(s,db,limit=None):
    q=db.query(Attendance).filter_by(student_id=s.id).order_by(Attendance.date.desc()); att=q.limit(limit).all() if limit else q.all()
    q=db.query(Evaluation).filter_by(student_id=s.id).order_by(Evaluation.date.desc()); ev=q.limit(limit).all() if limit else q.all()
    goals=db.query(TermGoal).filter_by(student_id=s.id).order_by(TermGoal.term).all()
    counts={k:db.query(Attendance).filter_by(student_id=s.id,status=k).count() for k in ['present','absent','excused','late','left']}
    return {'student':student_dict(s,db),'attendance':[{'id':a.id,'date':a.date,'status':a.status,'note':a.note or ''} for a in att],
            'evaluations':[{'id':e.id,'date':e.date,'score':e.score,'type':e.type,'notes':e.notes or ''} for e in ev],
            'goals':[{'id':g.id,'term':g.term,'target':g.target,'percent':g.percent} for g in goals], 'attendance_counts':counts}

@app.get('/api/health')
def health(db:Session=Depends(get_db)):
    from sqlalchemy import text
    db.execute(text('SELECT 1'))
    return {'status':'ok','version':'5.0.0','environment':settings.app_env}

@app.post('/api/auth/login')
def login(x:LoginIn,db:Session=Depends(get_db)):
    u=db.query(User).filter(User.username==x.username).first()
    if not u or u.role!=x.role or not verify_password(x.password,u.password_hash): raise HTTPException(401,'اسم المستخدم أو كلمة المرور غير صحيحة')
    return {'access_token':create_token(u),'token_type':'bearer','user':{'id':u.id,'username':u.username,'full_name':u.full_name,'role':u.role,'phone':u.phone}}
@app.get('/api/auth/me')
def me(u=Depends(get_user)): return {'id':u.id,'username':u.username,'full_name':u.full_name,'role':u.role,'phone':u.phone}

@app.get('/api/dashboard')
def dashboard(u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    students=db.query(Student).all() if u.role=='admin' else db.query(Student).filter(Student.teacher_id==u.id).all()
    ids=[s.id for s in students]
    aq=db.query(Attendance).filter(Attendance.student_id.in_(ids)) if ids else db.query(Attendance).filter(False)
    ev=db.query(Evaluation).filter(Evaluation.student_id.in_(ids)) if ids else db.query(Evaluation).filter(False)
    return {'students':len(students),'present':aq.filter(Attendance.status=='present').count(),'absent':aq.filter(Attendance.status=='absent').count(),
            'excused':aq.filter(Attendance.status=='excused').count(),'late':aq.filter(Attendance.status=='late').count(),
            'average_progress':round(sum(s.progress for s in students)/len(students)) if students else 0,
            'average_evaluation':round(sum(e.score for e in ev.all())/ev.count()) if ev.count() else 0,
            'starred':sum(1 for s in students if s.starred)}

@app.get('/api/students')
def list_students(search:str='',circle:str='',teacher_id:int|None=None,starred:bool|None=None,u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    q=db.query(Student)
    if u.role=='teacher': q=q.filter(Student.teacher_id==u.id)
    if search: q=q.filter(Student.full_name.contains(search))
    if circle: q=q.filter(Student.circle==circle)
    if teacher_id: q=q.filter(Student.teacher_id==teacher_id)
    if starred is not None: q=q.filter(Student.starred==starred)
    return [student_dict(s,db) for s in q.order_by(Student.starred.desc(),Student.full_name).all()]
@app.get('/api/students/{sid}')
def student_profile(sid:int,u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    s=db.get(Student,sid)
    if not s or not allowed_student(s,u): raise HTTPException(404,'الطالب غير موجود')
    return profile(s,db)
@app.post('/api/students')
def add_student(x:StudentIn,u=Depends(role('admin')),db:Session=Depends(get_db)):
    s=Student(**x.model_dump()); db.add(s); db.commit(); db.refresh(s); return student_dict(s,db)
@app.put('/api/students/{sid}')
def update_student(sid:int,x:StudentIn,u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    s=db.get(Student,sid)
    if not s or not allowed_student(s,u): raise HTTPException(404,'الطالب غير موجود')
    for k,v in x.model_dump().items(): setattr(s,k,v)
    db.commit(); db.refresh(s); return student_dict(s,db)
@app.delete('/api/students/{sid}')
def delete_student(sid:int,u=Depends(role('admin')),db:Session=Depends(get_db)):
    s=db.get(Student,sid)
    if not s: raise HTTPException(404,'الطالب غير موجود')
    db.query(Attendance).filter_by(student_id=sid).delete(); db.query(Evaluation).filter_by(student_id=sid).delete(); db.query(TermGoal).filter_by(student_id=sid).delete(); db.query(GuardianContact).filter_by(student_id=sid).delete(); db.delete(s); db.commit(); return {'message':'تم حذف الطالب'}
@app.post('/api/students/{sid}/star')
def star(sid:int,u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    s=db.get(Student,sid)
    if not s or not allowed_student(s,u): raise HTTPException(404,'الطالب غير موجود')
    s.starred=not s.starred; db.commit(); return {'starred':s.starred}
@app.post('/api/students/{sid}/guardian')
def guardian_contact(sid:int,x:GuardianIn,u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    s=db.get(Student,sid)
    if not s or not allowed_student(s,u): raise HTTPException(404,'الطالب غير موجود')
    g=db.query(GuardianContact).filter_by(student_id=sid).first()
    if not g: db.add(GuardianContact(student_id=sid,name=x.name,phone=x.phone))
    else: g.name=x.name; g.phone=x.phone
    db.commit(); return {'message':'تم حفظ بيانات ولي الأمر'}

@app.post('/api/attendance')
def attendance(x:AttendanceIn,u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    s=db.get(Student,x.student_id)
    if not s or not allowed_student(s,u): raise HTTPException(403,'لا تملك هذا الطالب')
    a=db.query(Attendance).filter_by(student_id=x.student_id,date=x.date).first()
    if not a: db.add(Attendance(**x.model_dump()))
    else: a.status=x.status; a.note=x.note
    db.commit(); return {'message':'تم حفظ الحضور'}
@app.get('/api/attendance')
def attendance_list(date:str='',student_id:int|None=None,u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    q=db.query(Attendance).join(Student,Student.id==Attendance.student_id)
    if u.role=='teacher': q=q.filter(Student.teacher_id==u.id)
    if date: q=q.filter(Attendance.date==date)
    if student_id: q=q.filter(Attendance.student_id==student_id)
    return [{'id':a.id,'student_id':a.student_id,'student_name':s.full_name,'date':a.date,'status':a.status,'note':a.note or ''} for a,s in q.order_by(Attendance.date.desc()).all()]

@app.post('/api/evaluations')
def evaluation(x:EvaluationIn,u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    s=db.get(Student,x.student_id)
    if not s or not allowed_student(s,u): raise HTTPException(403,'لا تملك هذا الطالب')
    db.add(Evaluation(**x.model_dump())); db.commit(); return {'message':'تم حفظ التقييم'}
@app.get('/api/evaluations')
def evaluations(student_id:int|None=None,u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    q=db.query(Evaluation).join(Student,Student.id==Evaluation.student_id)
    if u.role=='teacher': q=q.filter(Student.teacher_id==u.id)
    if student_id: q=q.filter(Evaluation.student_id==student_id)
    return [{'id':e.id,'student_id':e.student_id,'student_name':s.full_name,'score':e.score,'type':e.type,'notes':e.notes or '','date':e.date} for e,s in q.order_by(Evaluation.date.desc()).all()]

@app.post('/api/goals')
def add_goal(x:GoalIn,u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    s=db.get(Student,x.student_id)
    if not s or not allowed_student(s,u): raise HTTPException(403,'لا تملك هذا الطالب')
    db.add(TermGoal(**x.model_dump())); db.commit(); return {'message':'تم حفظ الهدف'}
@app.delete('/api/goals/{gid}')
def delete_goal(gid:int,u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    g=db.get(TermGoal,gid); s=db.get(Student,g.student_id) if g else None
    if not g or not s or not allowed_student(s,u): raise HTTPException(404,'الهدف غير موجود')
    db.delete(g); db.commit(); return {'message':'تم حذف الهدف'}

@app.get('/api/announcements')
def announcements(u=Depends(get_user),db:Session=Depends(get_db)):
    return [{'id':a.id,'title':a.title,'body':a.body,'created_at':a.created_at,'active':a.active} for a in db.query(Announcement).order_by(Announcement.id.desc()).all() if u.role=='admin' or a.active]
@app.post('/api/announcements')
def add_announcement(x:AnnouncementIn,u=Depends(role('admin')),db:Session=Depends(get_db)):
    a=Announcement(title=x.title,body=x.body,created_at=datetime.now().strftime('%Y-%m-%d %H:%M'),active=True); db.add(a); db.commit(); db.refresh(a); return {'id':a.id}
@app.delete('/api/announcements/{aid}')
def delete_announcement(aid:int,u=Depends(role('admin')),db:Session=Depends(get_db)):
    a=db.get(Announcement,aid)
    if not a: raise HTTPException(404,'الإعلان غير موجود')
    db.delete(a); db.commit(); return {'message':'تم حذف الإعلان'}

@app.get('/api/committee')
def committee(u=Depends(role('admin')),db:Session=Depends(get_db)):
    return {'tasks':[{'id':x.id,'text':x.text,'done':x.done} for x in db.query(CommitteeTask).all()], 'achievements':[{'id':x.id,'text':x.text} for x in db.query(CommitteeAchievement).all()]}
@app.post('/api/committee/tasks')
def task(x:TextIn,u=Depends(role('admin')),db:Session=Depends(get_db)):
    t=CommitteeTask(text=x.text); db.add(t); db.commit(); db.refresh(t); return {'id':t.id,'text':t.text,'done':t.done}
@app.patch('/api/committee/tasks/{tid}')
def task_toggle(tid:int,u=Depends(role('admin')),db:Session=Depends(get_db)):
    t=db.get(CommitteeTask,tid)
    if not t: raise HTTPException(404,'المهمة غير موجودة')
    t.done=not t.done; db.commit(); return {'done':t.done}
@app.delete('/api/committee/tasks/{tid}')
def task_delete(tid:int,u=Depends(role('admin')),db:Session=Depends(get_db)):
    t=db.get(CommitteeTask,tid)
    if not t: raise HTTPException(404,'المهمة غير موجودة')
    db.delete(t); db.commit(); return {'message':'تم حذف المهمة'}
@app.post('/api/committee/achievements')
def achievement(x:TextIn,u=Depends(role('admin')),db:Session=Depends(get_db)):
    a=CommitteeAchievement(text=x.text); db.add(a); db.commit(); db.refresh(a); return {'id':a.id,'text':a.text}
@app.delete('/api/committee/achievements/{aid}')
def achievement_delete(aid:int,u=Depends(role('admin')),db:Session=Depends(get_db)):
    a=db.get(CommitteeAchievement,aid)
    if not a: raise HTTPException(404,'الإنجاز غير موجود')
    db.delete(a); db.commit(); return {'message':'تم حذف الإنجاز'}

@app.get('/api/teachers')
def teachers(u=Depends(role('admin')),db:Session=Depends(get_db)):
    return [{'id':x.id,'full_name':x.full_name,'username':x.username,'phone':x.phone,'is_active':x.is_active} for x in db.query(User).filter(User.role=='teacher').order_by(User.full_name).all()]
@app.get('/api/users')
def users(u=Depends(role('admin')),db:Session=Depends(get_db)):
    return [{'id':x.id,'username':x.username,'full_name':x.full_name,'role':x.role,'phone':x.phone,'is_active':x.is_active} for x in db.query(User).order_by(User.role,User.full_name).all()]
@app.post('/api/users')
def add_user(x:UserIn,u=Depends(role('admin')),db:Session=Depends(get_db)):
    if x.role not in ROLES: raise HTTPException(400,'الدور غير صحيح')
    if db.query(User).filter_by(username=x.username).first(): raise HTTPException(400,'اسم المستخدم مستخدم مسبقًا')
    if not x.password: raise HTTPException(400,'كلمة المرور مطلوبة')
    n=User(username=x.username,password_hash=hash_password(x.password),role=x.role,full_name=x.full_name,phone=x.phone,is_active=x.is_active); db.add(n); db.commit(); db.refresh(n); return {'id':n.id}
@app.patch('/api/users/{uid}/status')
def user_status(uid:int,x:UserStatusIn,u=Depends(role('admin')),db:Session=Depends(get_db)):
    n=db.get(User,uid)
    if not n: raise HTTPException(404,'المستخدم غير موجود')
    n.is_active=x.is_active; db.commit(); return {'is_active':n.is_active}

@app.get('/api/guardian/children')
def children(u=Depends(role('guardian')),db:Session=Depends(get_db)):
    return [student_dict(s,db) for s in db.query(Student).filter(Student.guardian_id==u.id).all()]
@app.get('/api/guardian/child/{sid}')
def child(sid:int,u=Depends(role('guardian')),db:Session=Depends(get_db)):
    s=db.get(Student,sid)
    if not s or s.guardian_id!=u.id: raise HTTPException(403,'لا تملك الوصول لهذا الطالب')
    return profile(s,db,20)

@app.get('/api/reports/summary')
def report_summary(u=Depends(role('admin','teacher')),db:Session=Depends(get_db)):
    students=db.query(Student).all() if u.role=='admin' else db.query(Student).filter(Student.teacher_id==u.id).all()
    rows=[]
    for s in students:
        ev=db.query(Evaluation).filter_by(student_id=s.id).all(); att=db.query(Attendance).filter_by(student_id=s.id).all()
        avg=round(sum(x.score for x in ev)/len(ev)) if ev else 0
        present=sum(x.status=='present' for x in att); absent=sum(x.status=='absent' for x in att)
        rows.append({'id':s.id,'name':s.full_name,'circle':s.circle or '-','teacher':student_dict(s,db)['teacher_name'],'progress':s.progress,'evaluations':len(ev),'avg_score':avg,'present':present,'absent':absent})
    return rows


# Serve the production frontend from the same application.
frontend_dir = __import__('pathlib').Path(__file__).resolve().parent.parent / 'frontend'
if frontend_dir.exists():
    app.mount('/assets', StaticFiles(directory=str(frontend_dir)), name='assets')

@app.get('/', include_in_schema=False)
def frontend():
    return FileResponse(frontend_dir / 'index.html')
