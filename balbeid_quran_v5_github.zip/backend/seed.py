from .database import Base,engine,SessionLocal
from .models import *
from .auth import hash_password
Base.metadata.create_all(bind=engine)
db=SessionLocal()
def user(username,password,role,name,phone=None):
    u=db.query(User).filter_by(username=username).first()
    if not u:
        u=User(username=username,password_hash=hash_password(password),role=role,full_name=name,phone=phone); db.add(u); db.commit(); db.refresh(u)
    return u
admin=user('admin','Admin@12345','admin','مدير النظام')
teacher=user('teacher','Teacher@12345','teacher','معلم الحلقة','0500000000')
g1=user('guardian','Guardian@12345','guardian','ولي أمر محمد','0550000000')
g2=user('guardian2','Guardian@12345','guardian','ولي أمر أحمد','0550000001')
if not db.query(Student).first():
    students=[
      Student(full_name='محمد أحمد',guardian_id=g1.id,teacher_id=teacher.id,circle='حلقة الفجر',current_surah='البقرة',current_juz=2,progress=72,memorized_pages=35,starred=True),
      Student(full_name='أحمد خالد',guardian_id=g2.id,teacher_id=teacher.id,circle='حلقة الفجر',current_surah='آل عمران',current_juz=4,progress=54,memorized_pages=25),
      Student(full_name='عبدالله سالم',guardian_id=g1.id,teacher_id=teacher.id,circle='حلقة المغرب',current_surah='الكهف',current_juz=15,progress=83,memorized_pages=46),
    ]; db.add_all(students); db.commit()
if not db.query(Announcement).first():
    db.add_all([Announcement(title='موعد التقييم الشهري',body='سيكون التقييم الشهري يوم الخميس القادم. نأمل الالتزام بالحضور.',created_at='2026-10-08 14:00'),Announcement(title='تنبيه الحلقة',body='يرجى إحضار المصحف والالتزام بوقت الحلقة.',created_at='2026-10-07 18:00')]); db.commit()
if not db.query(CommitteeTask).first(): db.add_all([CommitteeTask(text='مراجعة سجل الحضور'),CommitteeTask(text='إعداد تقرير نهاية الشهر')]); db.commit()
if not db.query(CommitteeAchievement).first(): db.add(CommitteeAchievement(text='إطلاق بوابة ولي الأمر')); db.commit()
if not db.query(TermGoal).first():
    s=db.query(Student).first(); db.add_all([TermGoal(student_id=s.id,term='الفصل الأول',target='إتقان سورة البقرة من الآية 1 إلى 100',percent=65),TermGoal(student_id=s.id,term='الفصل الثاني',target='حفظ جزء عم',percent=30)]); db.commit()
db.close(); print('تم إنشاء قاعدة البيانات والحسابات التجريبية.')
print('admin / Admin@12345 | teacher / Teacher@12345 | guardian / Guardian@12345')
