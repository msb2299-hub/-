import os
os.environ.setdefault('DATABASE_URL', 'sqlite:///./test_balbeid.db')
os.environ.setdefault('SECRET_KEY', 'test-secret-key-for-ci-only-1234567890')
os.environ.setdefault('APP_ENV', 'test')
from fastapi.testclient import TestClient
from backend.main import app
from backend.database import Base, engine
Base.metadata.create_all(bind=engine)

def test_health():
    client = TestClient(app)
    r = client.get('/api/health')
    assert r.status_code == 200
    assert r.json()['status'] == 'ok'

def test_frontend_is_served():
    client = TestClient(app)
    r = client.get('/')
    assert r.status_code == 200
    assert 'متابعتي' in r.text
